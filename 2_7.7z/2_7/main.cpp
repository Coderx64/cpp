#include <iostream>
#include <fstream>
#include <listint.h>
#include <queueint.h>
#include <stackint.h>
#include <climits>

using namespace std;

//Removes all occurrences item x from of a specified stack
void remove_itemstack(tstack *&s, int x)
{
    tstack *r = init_stack();
    int i;

    while (!empty_stack(s))
    {
        i = pop(s);
        if (i != x)
        {
            push(r,i);
        }
    }

    s = r;
    r = NULL;
}

//Find the minimum element of the stack
int find_min(tstack *&s)
{
    tstack *r = init_stack();


    int item, min_item;

    min_item = INT_MAX;

    while (!empty_stack(s))
    {
        item = pop(s);
        if (item < min_item)
        {
            min_item = item;
        }
        push(r,item);
    }
    s = r;
    r = NULL;
    return min_item;
}

//Printing items of stack on screen
void print_stack(tstack *&s)
{
    int item;
    tstack *r = init_stack();

    while (!empty_stack(s))
    {
        item = pop(s);
        cout<<item<<" ";
        push(r, item);
    }

    s = r;
    r = NULL;
}

int main()
{
    ifstream in("input.txt");
    ofstream out("output.txt");
    int n,minn = INT_MAX;

    if (in.is_open()) cout<<"OK."<<endl; else return -1;

    tstack *head = init_stack();

    while (!in.eof())
    {
        in>>n;
        push(head, n);
    }

    print_stack(head);

    minn = find_min(head);
    cout<<endl;
    remove_itemstack(head, minn);

    print_stack(head);

    cout<<endl<<minn;

    /*---------�������----------*/
    in.close();
    in.open("input.txt");

    while (!in.eof())
    {
        in>>n;

    }

    /*---------------------------*/

    return 0;
}
